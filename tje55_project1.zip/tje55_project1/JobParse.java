/***************************************
 * JobParser.java
 * Parses job data to find entry-level jobs
 * @author Tyler Eaden
 * @version 1.0
 ****************************************/

import java.util.*;
import java.util.regex.*;
import java.io.*;

public class JobParse {
    public static void main(String args[]) {
        try {
            Scanner scan;
            ArrayList<Job> jobList = new ArrayList<Job>();

            if (args.length > 0) {
                scan = new Scanner(new File(args[0]));
            } else {
                System.out.println("Compile: javac JobParse.java");
                System.out.println("Usage: java JobParse readFile.csv(optional) writeFile(optional)\n");
                System.out.println("Could not find readFile; defaulting to \"lidata.csv\"\n");
                scan = new Scanner(new File("lidata.csv"));
            }

            // Skip CSV header section
            scan.nextLine();

            // Iterate over all job data
            while (scan.hasNextLine()) {

                // Isolate elements delineated by commas for current job
                /* Citation for Regex Pattern Reference:
                https://stackoverflow.com/questions/16206700/java-string-split-ignore-a-split-parameter */
                String[] jobArr = scan.nextLine().split(",(?!\\s)", 6);

                // Retrieve job data
                // Remove double quotation marks used for any CSV values that use commas
                String link = jobArr[0];
                String position = jobArr[1];
                String company = jobArr[2];
                String postDate = jobArr[3];
                String location = jobArr[4].substring(1, jobArr[4].length() - 1);
                String details = jobArr[5].substring(1, jobArr[5].length() - 1);

                // Proceed if job name related to tech and does not clearly exclude entry level
                /* Citation for Regex Pattern Reference:
                https://stackoverflow.com/questions/47877528/using-or-in-regex */
                if (position.matches("(?i).*(Engineer|Developer|Programmer).*")
                        && !position.matches("(?i).*(Senior|Sr.|Lead|Mid-Level|Associate).*")) {

                    // Proceed if years of experience required is less than 2
                    int yearReq = parseYears(details);
                    if (yearReq < 2) {
                        jobList.add(new Job(position, link, company, location, postDate, details, yearReq));
                    }
                }
            }

            scan.close();
            
            // Print and write to output file any entry-level jobs found
            int jobNum = jobList.size();
            if (jobNum > 0) {
                System.out.printf("You could be a good fit for %d entry-level jobs:\n\n", jobNum);
                for (Job job : jobList) {
                    System.out.println(job);
                    System.out.println();
                }

                String writeFileName = (args.length > 1) ? args[1] : "job-results.txt";
                writeFile(jobList, writeFileName);
            } else {
                System.out.println("Sorry! There were no entry-level jobs in the provided job data file");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Finds the years of experience requirement from a job description
    private static int parseYears(String description) {
        // Set required experience to unrealistically high number for initial comparison for min
        int yearsExp = 99;

        // Define pattern for extracting common strings that include the years of experience
        String regex = "(?i)([0-9]\\+ (yrs|years)|[0-9](-| to )[0-9] years|(?<!(-|\\+ ))[0-9] years)";

        /* Citation for Pattern and Matcher Explanation:
        https://stackoverflow.com/questions/237061/using-regular-expressions-to-extract-a-value-in-java */
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(description);

        // Identify the minimum year requirement on the job description
        while (matcher.find()) {
            String match = matcher.group(0);

            int minYear = Integer.parseInt(match.substring(0, 1));
            if (minYear < yearsExp) {
                yearsExp = minYear;
            }
        }

        // If years not mentioned in description, set requirement to 0
        yearsExp = (yearsExp == 99) ? 0 : yearsExp;
        return yearsExp;
    }

    // Writes list of jobs to output file
    private static void writeFile(ArrayList<Job> jobs, String fileName) {
        try {
            /* Citation: Reference for File Writing in Java:
            https://www.w3schools.com/java/java_files_create.asp */
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write("Job Post Link (Post Date)\n");

            for (Job job : jobs) {
                fileWriter.write(job.linkDate());
            }

            fileWriter.close();
            System.out.printf("Succesfully wrote %d entry-level job links to file: %s\n", jobs.size(), fileName);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}