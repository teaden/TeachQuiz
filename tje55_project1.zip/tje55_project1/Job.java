/***************************************
 * Job.java 
 * Has properties and behavior for a job posting
 * @author Tyler Eaden
 * @version 1.0
 ****************************************/

public class Job {

    private String position;
    private String link;
    private String company;
    private String location;
    private String postDate;
    private String details;
    private int yearsRequired;

    public Job() {
        this.position = "N/A";
        this.link = "N/A";
        this.company = "N/A";
        this.location = "N/A";
        this.postDate = "N/A";
        this.details = "N/A";
        this.yearsRequired = 0;
    }

    public Job(String title, String url, String co, String locale, String datePosted, String description, int years) {
        this.position = title;
        this.link = url;
        this.company = co;
        this.location = locale;
        this.postDate = datePosted;
        this.details = description;
        this.yearsRequired = years;
    }

    public String getPosition() {
        return this.position;
    }

    public String getLink() {
        return this.link;
    }

    public String getCompany() {
        return this.company;
    }

    public String getLocation() {
        return this.location;
    }

    public String getPostDate() {
        return this.postDate;
    }

    public String getDetails() {
        return this.details;
    }

    // Returns a more friendly (i.e., truncated) job description
    public String getTruncDetails() {
        return this.details.substring(0, this.details.length() / 3) + "...";
    }

    public int getYearsRequired() {
        return this.yearsRequired;
    }

    public void setPosition(String newPosition) {
        this.position = newPosition;
    }

    public void setLink(String newLink) {
        this.link = newLink;
    }

    public void setCompany(String newCo) {
        this.company = newCo;
    }

    public void setLocation(String newPlace) {
        this.location = newPlace;
    }

    public void setPostDate(String newDate) {
        this.postDate = newDate;
    }

    public void setDetails(String newDetails) {
        this.details = newDetails;
    }

    public void setYearsRequired(int newYears) {
        if (newYears >= 0) {
            this.yearsRequired = newYears;
        }
    }

    // Used for writing link and post date to output file for future reference
    public String linkDate() {
        return this.link + " (" + postDate + ")\n";
    }

    // Prints friendly message with all info about one job
    public String toString() {
        String info = "Title: " + this.getPosition() + "\nLink: " + this.getLink() + "\nCompany: " + this.getCompany() + "\nLocation: " + this.getLocation() + "\nDate Posted: " + this.getPostDate() + "\nDescription: " + this.getTruncDetails() + "\nYears Required: " + this.getYearsRequired();
        
        return info;
    }
}